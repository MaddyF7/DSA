# Create database
CREATE DATABASE dsa_tracker;
USE dsa_tracker;
# Create user table to store login credentials
CREATE TABLE User (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    role ENUM('Admin', 'Apprentice') NOT NULL,
    line_manager_id INT NULL,
    cohort INT NULL,
    start_date DATE NULL,
    end_date DATE NULL,
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
	modified_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
    FOREIGN KEY (line_manager_id) REFERENCES User(id)
);
# Create project table to store what each apprentice is working on
CREATE TABLE Project (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT NULL,
    start_date DATE NOT NULL,
    end_date DATE NULL,
    status ENUM('Ongoing', 'Completed') DEFAULT 'Ongoing' NOT NULL,
    apprentice_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
	modified_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
    FOREIGN KEY (apprentice_id) REFERENCES User(id)
);
# Create exam table to store exam progress
CREATE TABLE Exam (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    exam_date DATE NOT NULL,
    status ENUM('Scheduled', 'Completed', 'Unsuccessful') DEFAULT 'Scheduled' NOT NULL,
    apprentice_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    modified_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
    FOREIGN KEY (apprentice_id) REFERENCES User(id)
);
# Create leave table for storing time off
CREATE TABLE Leave_Request (
    id INT AUTO_INCREMENT PRIMARY KEY,
    apprentice_id INT NOT NULL,
    leave_type ENUM('Sick', 'Annual', 'Maternity', 'Paternity', 'Unpaid', 'Other') NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    status ENUM('Pending', 'Approved', 'Rejected') DEFAULT 'Pending' NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    modified_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
    FOREIGN KEY (apprentice_id) REFERENCES User(id)
);


# To insert test data
USE dsa_tracker;

INSERT INTO User (email, password, first_name, last_name, role, line_manager_id, cohort, start_date, end_date)
VALUES 
('admin1@fujitsu.com', 'adminpass1', 'John', 'Smith', 'Admin', NULL, NULL, NULL, NULL),
('admin2@fujitsu.com', 'adminpass2', 'Jane', 'Doe', 'Admin', NULL, NULL, NULL, NULL),
('apprentice1@fujitsu.com', 'pass1', 'Abi', 'Smith', 'Apprentice', 1, 2023, '2023-01-15', '2024-01-14'),
('apprentice2@fujitsu.com', 'pass2', 'Zainab', 'Green', 'Apprentice', 1, 2023, '2023-02-01', '2024-02-01'),
('apprentice3@fujitsu.com', 'pass3', 'Olivia', 'White', 'Apprentice', 2, 2024, '2024-03-01', '2025-03-01'),
('apprentice4@fujitsu.com', 'pass4', 'Lila', 'Black', 'Apprentice', 2, 2024, '2024-04-15', NULL),
('apprentice5@fujitsu.com', 'pass5', 'Mahad', 'Wilson', 'Apprentice', 1, 2023, '2023-01-10', '2024-01-10'),
('apprentice6@fujitsu.com', 'pass6', 'Duy', 'Taylor', 'Apprentice', 2, 2024, '2024-05-01', '2025-05-01'),
('apprentice7@fujitsu.com', 'pass7', 'Helen', 'Adams', 'Apprentice', 1, 2023, '2023-06-01', '2024-06-01'),
('apprentice8@fujitsu.com', 'pass8', 'Jude', 'King', 'Apprentice', 2, 2024, '2024-07-01', '2025-07-01');

INSERT INTO Exam (name, exam_date, status, apprentice_id)
VALUES 
('PL-900', '2023-02-20', 'Completed', 3),
('AZ-900', '2023-03-01', 'Completed', 3),
('DP-900', '2023-04-15', 'Scheduled', 4),
('PL-300', '2023-05-01', 'Unsuccessful', 4),
('AI-900', '2023-06-10', 'Completed', 5),
('SC-900', '2023-07-01', 'Scheduled', 5),
('MB-910', '2023-08-15', 'Completed', 6),
('PL-200', '2023-09-01', 'Unsuccessful', 6),
('AZ-104', '2023-10-10', 'Scheduled', 7),
('AZ-204', '2023-11-01', 'Completed', 8);

INSERT INTO Leave_Request (apprentice_id, leave_type, start_date, end_date, status)
VALUES 
(3, 'Annual', '2023-03-10', '2023-03-12', 'Approved'),
(3, 'Sick', '2023-05-20', '2023-05-22', 'Pending'),
(4, 'Annual', '2023-06-01', '2023-06-10', 'Approved'),
(4, 'Unpaid', '2023-07-15', '2023-07-20', 'Rejected'),
(5, 'Sick', '2023-08-05', '2023-08-07', 'Approved'),
(5, 'Annual', '2023-09-01', '2023-09-05', 'Pending'),
(6, 'Maternity', '2023-10-01', '2023-10-15', 'Approved'),
(6, 'Annual', '2023-11-01', '2023-11-05', 'Approved'),
(7, 'Sick', '2023-12-01', '2023-12-02', 'Pending'),
(8, 'Unpaid', '2023-12-20', '2023-12-25', 'Rejected');

INSERT INTO Project (name, description, start_date, end_date, status, apprentice_id)
VALUES 
('Leave App', 'Developing a leave request tracking system.', '2023-02-01', '2023-03-01', 'Completed', 3),
('Exam Tracker', 'Building an app to track exam progress.', '2023-03-10', '2023-04-10', 'Ongoing', 3),
('CRM Integration', 'Integrating CRM for client management.', '2023-05-01', '2023-06-01', 'Completed', 4),
('Data Pipeline', 'Automating data ingestion for analysis.', '2023-06-15', '2023-07-15', 'Ongoing', 4),
('Website Redesign', 'Redesigning company website.', '2023-07-01', '2023-08-01', 'Completed', 5),
('Mobile App', 'Building a mobile app for attendance tracking.', '2023-08-15', '2023-09-15', 'Ongoing', 5),
('Cybersecurity Audit', 'Conducting system security review.', '2023-09-01', '2023-10-01', 'Completed', 6),
('AI Chatbot', 'Developing an AI-powered chatbot.', '2023-10-10', '2023-11-10', 'Ongoing', 6),
('Network Setup', 'Configuring office network infrastructure.', '2023-11-01', '2023-12-01', 'Completed', 7),
('Power BI Dashboard', 'Creating dashboards for data analysis.', '2023-12-05', '2023-12-20', 'Ongoing', 8);